import java.io.*;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Stack;
import java.util.Scanner;

public class LL1 {
    public static void main(String[] args) {
    	System.out.println("Please input String to be processed:");
        Test test = new Test();
        test.createNvNt_set();
        test.transformGrammar();
        test.Init();
        test.createTable();
        test.ouput();
        test.analyzeLL();
    }
}

class Test {
    //��������first��
    public HashMap<Character, HashSet<Character>> firstSet = new HashMap<>();
    //���Ŵ�first��
    public HashMap<String, HashSet<Character>> firstSetX = new HashMap<>();
    //follow��
    public HashMap<Character, HashSet<Character>> followSet = new HashMap<>();
    //���ս��
    public HashSet<Character> VnSet = new HashSet<>();
    //�ս��
    public HashSet<Character> VtSet = new HashSet<>();
    //���ս��-����ʽ����
    public HashMap<Character, ArrayList<String>> experssionSet = new HashMap<>();
    //Ԥ�������
    public String[][] table;
    //�����ķ�
    public String[] inputExperssion = {"E->Te", "e->ATe", "e->~", "T->Ft", "t->MFt", "t->~", "F->(E)", "F->i", "A->+", "A->-", "M->*", "M->/"};
    //��ʼ��
    public char S = inputExperssion[0].charAt(0);
    //����ջ
    public Stack<Character> analyzeStatck = new Stack<>();
    //���봮
    Scanner Scan =new Scanner(System.in);
    String nextStr_fromBuffer=Scan.nextLine();
    public String strInput=nextStr_fromBuffer+"$";//ĩβ����$��ʾ����
    public String action = "";
    int index = 0;

    public void Init() {
        //������ս����first��
        for (char c : VnSet)
            getFirst(c);
        //���쿪ʼ����follow��
        getFollow(S);
        //������ս����follow��
        for (char c : VnSet)
            getFollow(c);
    }

     //������ս���������ս��
    public void createNvNt_set() {
        for (String e : inputExperssion)
            VnSet.add(e.split("->")[0].charAt(0));
        for (String e : inputExperssion)
            for (char c : e.split("->")[1].toCharArray())
                if (!VnSet.contains(c))
                    VtSet.add(c);
    }

    //�����ķ�
    public void transformGrammar() {
        for (String e : inputExperssion) {
            String[] str = e.split("->");
            char c = str[0].charAt(0);
            ArrayList<String> list = experssionSet.containsKey(c) ? experssionSet.get(c) : new ArrayList<>();
            list.add(str[1]);
            experssionSet.put(c, list);
        }
        Object[] VnArray = VnSet.toArray();
        for (int i = 0; i < VnArray.length; i++) {
            for (int j = 0; j < i; j++) {
                for (String e : inputExperssion) {
                    String[] str = e.split("->");
                    char ch = str[0].charAt(0);
                    String s = str[1];
                    if (VnArray[i].equals(ch)) {
                        if (s.substring(0, 1).equals(VnArray[j].toString())) {
                            for (String e1 : inputExperssion) {
                                String[] str1 = e1.split("->");
                                char ch1 = str1[0].charAt(0);
                                String s1 = str1[1];
                                if (VnArray[j].equals(ch1)) {
                                    String str2 = s.substring(1);
                                    ArrayList<String> list = experssionSet.containsKey(ch) ? experssionSet.get(ch) : new ArrayList<>();
                                    list.add(s1 + str2);
                                    list.remove(s);
                                    experssionSet.put(ch, list);
                                }
                            }
                        }
                    }
                }
            }
        }

        HashMap<Character, ArrayList<String>> experssionSetTemp1 = new HashMap<>();
        experssionSetTemp1 = clone(experssionSet);
        HashSet<Character> VnSetTemp = new HashSet<>();
        VnSetTemp = clone(VnSet);

        for (int i = 0; i < VnArray.length; i++) {
            int flag = 0;
            for (char ch : VnSet){
                for (String s : experssionSet.get(ch)){
                    if (VnArray[i].equals(ch)){
                        if (ch == s.charAt(0)){
                            flag++;
                        }
                    }
                }
            }
            if (flag == 0) continue;
            for (char ch : VnSet){
                for (String s : experssionSet.get(ch)){
                    if (VnArray[i].equals(ch)){
                        if (ch == s.charAt(0)){
                            String str = s.substring(1);
                            ArrayList<String> listT = experssionSetTemp1.containsKey(ch) ? experssionSetTemp1.get(ch) : new ArrayList<>();
                            listT.remove(s);
                            experssionSetTemp1.put(ch, listT);
                            ArrayList<String> list = experssionSetTemp1.containsKey(Character.toLowerCase(ch)) ? experssionSetTemp1.get(Character.toLowerCase(ch)) : new ArrayList<>();
                            list.add(str + Character.toLowerCase(ch));
                            experssionSetTemp1.put(Character.toLowerCase(ch), list);
                            ArrayList<String> list1 = experssionSetTemp1.containsKey(Character.toLowerCase(ch)) ? experssionSetTemp1.get(Character.toLowerCase(ch)) : new ArrayList<>();
                            list1.add("~");
                            experssionSetTemp1.put(Character.toLowerCase(ch), list);
                            VnSetTemp.add(Character.toLowerCase(ch));
                        }else{
                            ArrayList<String> list = experssionSetTemp1.containsKey(ch) ? experssionSetTemp1.get(ch) : new ArrayList<>();
                            list.remove(s);
                            list.add(s + Character.toLowerCase(ch));
                            experssionSetTemp1.put(ch, list);
                        }
                    }
                }
            }
        }

        System.out.println("\nTransform the Grammar to:");
        for (char c : VnSetTemp)
            for (String s : experssionSetTemp1.get(c))
                System.out.println(c + "->" + s);
        VnSet = clone(VnSetTemp);
        experssionSet = clone(experssionSetTemp1);
    }

    @SuppressWarnings("unchecked")
    public static <T extends Serializable> T clone(T obj) {
        T clonedObj = null;
        try {
            ByteArrayOutputStream baos = new ByteArrayOutputStream();
            ObjectOutputStream oos = new ObjectOutputStream(baos);
            oos.writeObject(obj);
            oos.close();
            ByteArrayInputStream bais = new ByteArrayInputStream(baos.toByteArray());
            ObjectInputStream ois = new ObjectInputStream(bais);
            clonedObj = (T) ois.readObject();
            ois.close();
        } catch (Exception e) {
            e.printStackTrace();
        }
        return clonedObj;
    }

    public void getFirst(char c) {
        if (firstSet.containsKey(c))
            return;
        HashSet<Character> set = new HashSet<>();
        // ��cΪ�ս����ֱ������
        if (VtSet.contains(c)) {
            set.add(c);
            firstSet.put(c, set);
            return;
        }
        // cΪ���ս���ţ�������ÿ������ʽ
        for (String s : experssionSet.get(c)) {
            if ("~".equals(c)) {
                set.add('~');
            } else {
                for (char cur : s.toCharArray()) {
                    if (!firstSet.containsKey(cur))
                        getFirst(cur);
                    HashSet<Character> curFirst = firstSet.get(cur);
                    set.addAll(curFirst);
                    if (!curFirst.contains('~'))
                        break;
                }
            }
        }
        firstSet.put(c, set);
    }

    public void getFirst(String s) {
        if (firstSetX.containsKey(s))
            return;
        HashSet<Character> set = new HashSet<>();
        // ��������ɨ���ʽ
        int i = 0;
        while (i < s.length()) {
            char cur = s.charAt(i);
            if (!firstSet.containsKey(cur))
                getFirst(cur);
            HashSet<Character> rightSet = firstSet.get(cur);
            // ����ǿ�first��������
            set.addAll(rightSet);
            // �������մ� ������һ������
            if (rightSet.contains('~'))
                i++;
            else
                break;
            // ������β�� �����з��ŵ�first���������մ� �ѿմ�����fisrt��
            if (i == s.length()) {
                set.add('~');
            }
        }
        firstSetX.put(s, set);
    }


    //��follow��
    public void getFollow(char c) {
        ArrayList<String> list = experssionSet.get(c);
        HashSet<Character> leftFollowSet = followSet.containsKey(c) ? followSet.get(c) : new HashSet<>();
        //����ǿ�ʼ�� ���� $
        if (c == S)
            leftFollowSet.add('$');
        //������������в���ʽ������c�ĺ���ս��
        for (char ch : VnSet)
            for (String s : experssionSet.get(ch))
                for (int i = 0; i < s.length(); i++)
                    if (c == s.charAt(i) && i + 1 < s.length() && VtSet.contains(s.charAt(i + 1)))
                        leftFollowSet.add(s.charAt(i + 1));
        followSet.put(c, leftFollowSet);
        //����ɨ�账��c��ÿһ������ʽ
        for (String s : list) {
            int i = s.length() - 1;
            while (i >= 0) {
                char cur = s.charAt(i);
                //ֻ�������ս��
                if (VnSet.contains(cur)) {
                    //1.���²�����   followA ���� followB
                    //2.���´��ڣ��Ѧµ�first���ǿշ��ż���followB
                    //3.���´���  ��first(��)�����մ�  followA ���� followB
                    String right = s.substring(i + 1);
                    HashSet<Character> rightFirstSet;
                    if(!followSet.containsKey(cur))
                        getFollow(cur);
                    HashSet<Character> curFollowSet = followSet.get(cur);
                    //followA����followB
                    if (right.length() == 0) {
                        curFollowSet.addAll(leftFollowSet);
                    } else {
                        if (right.length() == 1) {
                            if (!firstSet.containsKey(right.charAt(0)))
                                getFirst(right.charAt(0));
                            rightFirstSet = firstSet.get(right.charAt(0));
                        } else {
                            if (!firstSetX.containsKey(right))
                                getFirst(right);
                            rightFirstSet = firstSetX.get(right);
                        }
                        for (char var : rightFirstSet)
                            if (var != '~')
                                curFollowSet.add(var);
                        // ��first(��)�����մ�,��followA����followB
                        if (rightFirstSet.contains('~'))
                            curFollowSet.addAll(leftFollowSet);
                    }
                    followSet.put(cur, curFollowSet);
                }
                i--;
            }
        }
    }

    //����Ԥ�������
    public void createTable() {
        Object[] VtArray = VtSet.toArray();
        Object[] VnArray = VnSet.toArray();
        table = new String[VnArray.length + 1][VtArray.length + 1];
        table[0][0] = " ";
        for (int i = 0; i < VtArray.length; i++)
            table[0][i + 1] = (VtArray[i].toString().charAt(0) == '~') ? "$" : VtArray[i].toString();
        for (int i = 0; i < VnArray.length; i++)
            table[i + 1][0] = VnArray[i] + "";
        for (int i = 0; i < VnArray.length; i++)
            for (int j = 0; j < VtArray.length; j++)
                table[i + 1][j + 1] = " ";
        for (char A : VnSet) {
            for (String s : experssionSet.get(A)) {
                if (!firstSetX.containsKey(s))
                    getFirst(s);
                HashSet<Character> set = firstSetX.get(s);
                for (char a : set)
                    insert(A, a, s);
                if (set.contains('~')) {
                    HashSet<Character> setFollow = followSet.get(A);
                    if (setFollow.contains('$'))
                        insert(A, '$', s);
                    for (char b : setFollow)
                        insert(A, b, s);
                }
            }
        }
    }

    //��������
    public void analyzeLL() {
        System.out.println();
        System.out.println("Analysis Process as follow:");
        System.out.println("               Stack         Input              Output");
        analyzeStatck.push('$');
        analyzeStatck.push(S);
        displayLL();
        char X = analyzeStatck.peek();
        while (X != '$') {
            char a = strInput.charAt(index);
            if (X == a) {
                action = "match " + analyzeStatck.peek();
                analyzeStatck.pop();
                index++;
            } else if (VtSet.contains(X)) {
                System.out.println("Error:Unexpected LL(1) String!");
                return;
            }
            else if (find(X, a).equals(" ")) {
                System.out.println("Error:Unexpected LL(1) String!");
                return;
            }
            else if (find(X, a).equals("~")) {
                analyzeStatck.pop();
                action = X + "->~";
            } else {
                String str = find(X, a);
                if (str != "") {
                    action = X + "->" + str;
                    analyzeStatck.pop();
                    int len = str.length();
                    for (int i = len - 1; i >= 0; i--)
                        analyzeStatck.push(str.charAt(i));
                } else {
                    System.out.println("Error:Unexpected LL(1) String!");
                    return;
                }
            }
            X = analyzeStatck.peek();
            displayLL();
        }
        System.out.println("\nSuccess!");
    }


    public String find(char X, char a) {
        for (int i = 0; i < VnSet.size() + 1; i++) {
            if (table[i][0].charAt(0) == X)
                for (int j = 0; j < VtSet.size() + 1; j++) {
                    if (table[0][j].charAt(0) == a)
                        return table[i][j];
                }
        }
        return "";
    }

    public void insert(char X, char a, String s) {
        if (a == '~') a = '$';
        for (int i = 0; i < VnSet.size() + 1; i++) {
            if (table[i][0].charAt(0) == X) {
                for (int j = 0; j < VtSet.size() + 1; j++) {
                    if (table[0][j].charAt(0) == a) {
                        if (!(table[i][j].equals(" ") || table[i][j].equals(s))){
                            System.out.println("Not LL1 Grammar!");
                            return;
                        }
                        table[i][j] = s;
                        return;
                    }
                }
            }
        }
    }

    // �����������
    public void displayLL() {
        Stack<Character> s = analyzeStatck;
        System.out.printf("%20s", s);
        System.out.printf("%15s", strInput.substring(index));
        System.out.printf("%17s", action);
        System.out.println();
    }

    public void ouput() {
        System.out.println("\nFirst-Set as follow:");
    	//first��
        for (Character c : VnSet) {
            HashSet<Character> set = firstSet.get(c);
            System.out.printf("first(" + c + "):");
            for (Character var : set)
                System.out.print(var + " ");
            System.out.println();
        }

        System.out.println("\nFollow-Set as follow:");
        //follow��
        for (Character c : VnSet) {
            HashSet<Character> set = followSet.get(c);
            System.out.print("follow(" + c + "):");
            for (Character var : set)
                System.out.print(var + " ");
            System.out.println();
        }
        System.out.println();

        //Ԥ�������
        System.out.println("LL(1) Analysis Table as follow:");
        for (int i = 0; i < VnSet.size() + 1; i++) {
            for (int j = 0; j < VtSet.size() + 1; j++) {
                System.out.printf("%6s", table[i][j] + " ");
            }
            System.out.println();
        }
    }

}